require("nvchad.configs.lspconfig").defaults()

-- Configure servers using vim.lsp.config (Neovim 0.11+)
vim.lsp.config("html", {})
vim.lsp.config("cssls", {})

-- Bash LSP with proper cmd
vim.lsp.config("bashls", {
  cmd = { vim.fn.expand("~/.local/share/nvim/mason/bin/bash-language-server"), "start" },
})

-- Ruby LSP - use ruby from mise with the installed ruby-lsp
vim.lsp.config("ruby_lsp", {
  cmd = { vim.fn.expand("~/.local/share/mise/installs/ruby/3.0.7/bin/ruby"),
          vim.fn.expand("~/.local/share/nvim/mason/packages/ruby-lsp/bin/ruby-lsp") },
  root_markers = { "Gemfile", ".git" },
})

-- TypeScript LSP
vim.lsp.config("ts_ls", {
  root_markers = { "package.json", "tsconfig.json", ".git" },
  single_file_support = true,
})

-- Enable all configured servers
vim.lsp.enable({ "html", "cssls", "bashls", "ruby_lsp", "ts_ls" }) 
